package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Programa extends Application {

	@Override
	public void start(Stage primaryStage) {
		Scene menuPrincipal = new MenuPrincipal(primaryStage, new Juego());

		primaryStage.setTitle("AlgoMon");
		primaryStage.setScene(menuPrincipal);
		primaryStage.setFullScreen(true);
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}

}
