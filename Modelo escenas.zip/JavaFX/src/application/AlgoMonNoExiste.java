package application;

public class AlgoMonNoExiste extends RuntimeException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

}
