package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class MenuPrincipal extends EscenaJuegoAlgoMon {

	public MenuPrincipal(Stage stage, Juego juego) {
		super(stage, juego);
	}

	@Override
	protected void agregarElementos() {
		HBox botonera = new HBox();

		Button unJugador = this.crearBotonConTexto("Un jugador");
		Button dosJugadores = this.crearBotonConTexto("Dos jugadores");
		Button cheatCode = this.crearBotonConTexto("Cheat code");
		Button salir = this.crearBotonConTexto("Salir");

		dosJugadores.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				stage.setScene(new ElegirEquipoJugador1(stage, juego));
			}

		});

		botonera.getChildren().addAll(unJugador, dosJugadores, cheatCode, salir);
		this.setRoot(botonera);
	}

}
