package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class MenuPrincipal extends EscenaJuegoAlgoMon {

	public MenuPrincipal(Stage stage, Juego juego) {
		super(stage, "Fondo.png", juego);
	}

	@Override
	protected void agregarElementos() {
		BorderPane layout = new BorderPane();
		HBox botonera = new HBox(20);
		BarraMenu barraMenu = new BarraMenu();

		Image imagenLogo = new Image(ruta + "Logo.png");
		ImageView logoView = new ImageView(imagenLogo);
		HBox logo = new HBox(logoView);

		Button unJugador = new Boton("Un jugador");
		Button dosJugadores = new Boton("Dos jugadores");
		Button cheatCode = new Boton("Cheat code");
		Button salir = new Boton("Salir");

		dosJugadores.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				stage.setScene(new ElegirEquipoJugador1(stage, juego));
			}

		});

		botonera.getChildren().addAll(unJugador, dosJugadores, cheatCode, salir);
		botonera.setPadding(new Insets(50f));
		botonera.setAlignment(Pos.CENTER);

		logo.setPadding(new Insets(20));
		logo.setAlignment(Pos.TOP_CENTER);

		layout.setTop(barraMenu);
		layout.setCenter(logo);
		layout.setBottom(botonera);
		layout.setBackground(this.fondo);

		this.setRoot(layout);
	}

}
