package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ElegirEquipoJugador2 extends ElegirEquipo {

	public ElegirEquipoJugador2(Stage stage, Juego juego) {
		super(stage, juego);
	}

	@Override
	protected void setAccionFinalizarSeleccion() {
		this.finalizarSeleccion.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				stage.setScene(new EscenaBatalla(stage, juego));
			}

		});
	}

	@Override
	protected Node getTextoPantalla() {
		Label texto = new Label();

		texto.setText("Jugador 2");
		return texto;
	}

}
