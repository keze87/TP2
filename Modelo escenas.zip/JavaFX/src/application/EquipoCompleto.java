package application;

public class EquipoCompleto extends RuntimeException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public EquipoCompleto(String mensaje) {
		super(mensaje);
	}

}
