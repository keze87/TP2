package application;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public abstract class EscenaJuegoAlgoMon extends Scene {

	protected Stage stage;
	protected Background fondo;
	protected Juego juego;
	protected static String ruta = "file:src/imagenes/";

	public EscenaJuegoAlgoMon(Stage stage, String nombreImagenFondo, Juego juego) {
		super(new Pane(), 500, 400);
		this.stage = stage;
		this.juego = juego;
		this.crearFondo(nombreImagenFondo);
		this.agregarElementos();
	}

	protected Button crearBotonConTexto(String texto) {
		Button boton = new Boton(texto);

		return boton;
	}

	protected abstract void agregarElementos();

	private void crearFondo(String nombreImagenFondo) {
		Image imagenFondo = new Image(EscenaJuegoAlgoMon.ruta + nombreImagenFondo);

		BackgroundImage fondo = new BackgroundImage(imagenFondo, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.CENTER, BackgroundSize.DEFAULT);

		this.fondo = new Background(fondo);
	}

}
