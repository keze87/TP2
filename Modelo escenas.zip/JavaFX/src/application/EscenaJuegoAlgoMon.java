package application;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public abstract class EscenaJuegoAlgoMon extends Scene {

	protected Stage stage;
	protected Juego juego;

	public EscenaJuegoAlgoMon(Stage stage, Juego juego) {
		super(new Pane(), 500, 400);
		this.stage = stage;
		this.juego = juego;
		this.agregarElementos();
	}

	protected Button crearBotonConTexto(String texto) {
		Button boton = new Button();

		boton.setText(texto);
		return boton;
	}

	protected abstract void agregarElementos();

}
