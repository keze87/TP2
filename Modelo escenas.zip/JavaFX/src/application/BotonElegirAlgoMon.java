package application;

import java.lang.reflect.Method;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import src.fiuba.algo3.modelo.AlgoMon;
import src.fiuba.algo3.modelo.AlgoMonBuilder;

public class BotonElegirAlgoMon extends Button {

	private AlgoMon algoMon;

	public BotonElegirAlgoMon(String nombreAlgoMon) {
		this.algoMon = this.crearAlgoMon(nombreAlgoMon);
		this.agregarContenido();
	}

	private AlgoMon crearAlgoMon(String nombreAlgoMon) {
		try {
			Method metodo = AlgoMonBuilder.class.getMethod("crear" + nombreAlgoMon);

			return (AlgoMon) metodo.invoke(null);
		} catch(Exception e) {
			throw new AlgoMonNoExiste();
		}
	}

	private void agregarContenido() {
		this.setPadding(new Insets(50f));
		this.setMinWidth(250f);
		this.setMinHeight(200f);
		this.setText(algoMon.getNombre() + "\n" + (int) algoMon.getVidaMaxima() + " HP");

		Image imagenAlgoMon = new Image("file:src/imagenes/" + this.algoMon.getNombre() + ".gif");

		this.setGraphic(new ImageView(imagenAlgoMon));
	}

}
