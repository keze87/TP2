package application;

import java.lang.reflect.Method;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import src.fiuba.algo3.modelo.AlgoMon;
import src.fiuba.algo3.modelo.AlgoMonBuilder;

public class BotonElegirAlgoMon extends Button {

	private AlgoMon algoMon;
	private Jugador jugador;

	public BotonElegirAlgoMon(String nombreAlgoMon, Jugador jugador) {
		this.algoMon = this.crearAlgoMon(nombreAlgoMon);
		this.jugador = jugador;
		this.agregarContenido();
		this.establecerAccion();
	}

	private AlgoMon crearAlgoMon(String nombreAlgoMon) {
		try {
			Method metodo = AlgoMonBuilder.class.getMethod("crear" + nombreAlgoMon);

			return (AlgoMon) metodo.invoke(null);
		} catch(Exception e) {
			throw new AlgoMonNoExiste();
		}
	}

	private void agregarContenido() {
		this.setPadding(new Insets(20f));
		this.setMinWidth(180f);
		this.setMinHeight(100f);
		this.setText(algoMon.getNombre() + "\n" + (int) algoMon.getVidaMaxima() + " HP");

		Image imagenAlgoMon = new Image("file:src/imagenes/" + this.algoMon.getNombre() + ".gif");

		this.setGraphic(new ImageView(imagenAlgoMon));
	}

	private void establecerAccion() {
		this.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {

				if(jugador.tieneAlgoMonEnEquipo(algoMon)) {
					jugador.sacarAlgoMonDelEquipo(algoMon);
					Consola.mostrarMensaje(algoMon.getNombre() + " fue removido del equipo.");
				}

				else {
					try {
						jugador.agregarAlgoMonAlEquipo(algoMon);
						Consola.mostrarMensaje(algoMon.getNombre() + " fue agregado al equipo.");
					} catch (EquipoCompleto e) {
						Consola.mostrarMensaje(e.getMessage());
					}
				}
			}

		});
	}

}
