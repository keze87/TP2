package application;

import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public abstract class ElegirEquipo extends EscenaJuegoAlgoMon {

	protected Button finalizarSeleccion;

	public ElegirEquipo(Stage stage, Juego juego) {
		super(stage, "", juego);
	}

	@Override
	protected void agregarElementos() {
		VBox filas = new VBox();
		HBox filaSuperior = new HBox();

		filas.getChildren().add(this.getTextoPantalla());

		filaSuperior.getChildren().add(this.crearBotonConTexto("Charmander"));
		filaSuperior.getChildren().add(this.crearBotonConTexto("Squirtle"));
		filaSuperior.getChildren().add(this.crearBotonConTexto("Bulbasaur"));

		HBox filaInferior = new HBox();

		filaInferior.getChildren().add(this.crearBotonConTexto("Jigglypuff"));
		filaInferior.getChildren().add(this.crearBotonConTexto("Chansey"));
		filaInferior.getChildren().add(this.crearBotonConTexto("Rattata"));

		filas.getChildren().add(filaSuperior);
		filas.getChildren().add(filaInferior);

		this.finalizarSeleccion = this.crearBotonConTexto("Listo");
		this.setAccionFinalizarSeleccion();
		filas.getChildren().add(this.finalizarSeleccion);
		this.setRoot(filas);
	}

	protected abstract Node getTextoPantalla();
	protected abstract void setAccionFinalizarSeleccion();

}
