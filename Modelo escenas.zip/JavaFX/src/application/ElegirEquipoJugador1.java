package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ElegirEquipoJugador1 extends ElegirEquipo {

	public ElegirEquipoJugador1(Stage stage, Juego juego) {
		super(stage, juego);
	}

	@Override
	protected void setAccionFinalizarSeleccion() {
		this.finalizarSeleccion.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				stage.setScene(new ElegirEquipoJugador2(stage, juego));
			}

		});
	}

	@Override
	protected Node getTextoPantalla() {
		Label texto = new Label();

		texto.setText("Jugador 1");
		return texto;
	}

}
